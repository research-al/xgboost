"""Feature engineering module."""

from kiba_model.features.engineering import FeatureEngineering

__all__ = ["FeatureEngineering"]