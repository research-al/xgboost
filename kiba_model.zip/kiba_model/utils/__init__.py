"""Utility functions for KIBA prediction model."""

from kiba_model.utils.logging import setup_logging

__all__ = ["setup_logging"]
