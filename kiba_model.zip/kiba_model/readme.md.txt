# KIBA Protein-Ligand Binding Affinity Prediction

An object-oriented framework for predicting protein-ligand binding affinity using the KIBA (Kinase Inhibitor BioActivity) dataset.

## Overview

This package provides a comprehensive pipeline for:
- Preprocessing protein and compound data
- Engineering features using pre-computed embeddings
- Training XGBoost models to predict binding affinity
- Evaluating model performance
- Making predictions for new protein-ligand pairs

The modular, object-oriented architecture makes it easy to extend or modify individual components while maintaining a cohesive workflow.

## Installation

### Requirements

- Python 3.8+
- NumPy
- Pandas
- Matplotlib
- Seaborn
- XGBoost
- H5py
- Scikit-learn
- PyTorch (optional, for deep learning extensions)

### Setup

```bash
# Clone the repository
git clone https://github.com/yourusername/kiba-model.git
cd kiba-model

# Install dependencies
pip install -r requirements.txt
```

## Directory Structure

```
kiba_model/
├── __init__.py                # Package initialization
├── config.py                  # Configuration class
├── data/
│   ├── __init__.py
│   ├── loader.py              # DataLoader class
│   └── preprocessor.py        # DataPreprocessor class
├── features/
│   ├── __init__.py
│   └── engineering.py         # FeatureEngineering class
├── modeling/
│   ├── __init__.py
│   ├── trainer.py             # ModelTrainer class
│   ├── evaluator.py           # ModelEvaluator class
│   └── predictor.py           # Predictor class
├── utils/
│   ├── __init__.py
│   ├── logging.py             # Logging utilities
│   └── visualization.py       # Visualization utilities
├── pipeline.py                # KIBAModelPipeline class
└── main.py                    # Command-line interface
```

## Data Preparation

The pipeline requires three input files:
1. **KIBA dataset** (interactions between proteins and compounds with binding affinity values)
2. **Protein sequences** (FASTA format or CSV)
3. **Compound SMILES** (CSV format)

Example file formats:

### KIBA CSV format
```
UniProt_ID,pubchem_cid,kiba_score,kiba_score_estimated
P31749,10184653,0.0,False
P31749,11439844,20.35,True
...
```

### Protein Sequences CSV format
```
UniProt_ID,Protein_Sequence
P31749,MSDVAIVKEGWLHKRGEYIKTWRPRYFLLKNDGTFIGYKERPQDVDQREAPLNNFSVAQCQLMKTERPRPNTFIIRCLQWTTVIERTFHVETPEEREEWTTAIQTVADGLKRQEEETMDFRSGSPSDNSGAEEMEVSLAKPKHRVTMNEFETDRKSYPEIFLSDEQLDYFRNEPLTEIRNRHKLCNSPLFKLLSVYQNKGSKGSALNLPSLIGLMCFSFQVKDLREYRSLIYQTDLTKDLLICAFQVKDEKGVAGLPG
O75116,MAGAGPGAGLRLLPPPLRRLGALLLLLAPLLLGALAGRLADNTLQAEKCNRITTHNPAACLGERYESYLRPVDSYPFLNFLFVESGNLITGVANEHAEIISNIITNNYGDLQRIHPDLNIDGFSEISKISLAEMIFNRFLFQKNSVIFNVNNSDYITRRSRSGSFNESTMNNNNNNNKSDSKNNSYIINKQLEESKKLLLLGLSPSHKSTFTAGNHLKSIYQNISVVNMSKGKIALTVPNLNRKFFHCGCNKEMLDVVVKYTWNVPSLDRDKRNKCASRENKQILVKCSCYEVDNRSVSF
...
```

### Compound SMILES CSV format
```
cid,smiles
10184653,CC(C)SC1=NC(=NC(=O)C1=O)C2=CC=CC=C2
11439844,CCN1CCN(CC1)C(=O)C2=CC3=C(C=C2OC)OCO3
...
```

## Usage

### Command Line Interface

The package provides a command-line interface for running the pipeline:

```bash
python -m kiba_model.main --kiba-file path/to/kiba.csv --protein-file path/to/protein_sequences.csv --compound-file path/to/cid_smiles_extracted.csv
```

#### Required Arguments:
- `--kiba-file`: Path to the KIBA dataset file
- `--protein-file`: Path to the protein sequences file
- `--compound-file`: Path to the compound SMILES file

#### Optional Arguments:
- `--data-dir`: Directory for data files (default: "data")
- `--models-dir`: Directory for model files (default: "models")
- `--results-dir`: Directory for results files (default: "results")
- `--logs-dir`: Directory for log files (default: "logs")
- `--kiba-threshold`: Upper threshold for KIBA scores (default: 100.0)
- `--protein-min-length`: Minimum protein sequence length (default: 100)
- `--protein-max-length`: Maximum protein sequence length (default: 2000)
- `--smiles-max-length`: Maximum SMILES string length (default: 200)
- `--log10`: Use log10 transformation (default: natural log if not specified)
- `--no-gpu`: Disable GPU acceleration
- `--no-stratification`: Disable stratified sampling
- `--predict-only`: Only set up for prediction (no training)
- `--no-backup`: Do not backup existing files
- `--allow-empty`: Allow empty results after filtering
- `--min-interactions`: Minimum number of valid interactions required (default: 50)
- `--seed`: Random seed for reproducibility (default: 42)
- `--verbose`: Enable verbose logging

### Example Commands

#### Train a model
```bash
python -m kiba_model.main --kiba-file kiba.csv --protein-file protein_sequences.csv --compound-file cid_smiles_extracted.csv --log10 --verbose
```

#### Make predictions only
```bash
python -m kiba_model.main --kiba-file kiba.csv --protein-file protein_sequences.csv --compound-file cid_smiles_extracted.csv --predict-only
```

## Pipeline Steps

The KIBA prediction pipeline consists of the following steps:

### 1. Preprocessing
- Loads raw data files
- Validates data quality
- Filters proteins by sequence length
- Filters compounds by SMILES complexity
- Filters interactions by KIBA score threshold
- Converts IDs to consistent formats
- Creates stratification labels

### 2. Feature Engineering
- Loads pre-computed protein and compound embeddings
- Creates feature matrix by combining embeddings
- Applies log or log10 transformation to KIBA scores
- Handles missing or problematic values

### 3. Model Training
- Splits data into training, validation, and test sets
- Trains initial XGBoost model
- Tunes hyperparameters
- Trains final model on combined training and validation data

### 4. Evaluation
- Evaluates model on test set
- Calculates metrics (RMSE, MAE, R²)
- Generates visualizations
  - Actual vs. predicted values
  - Feature importance
  - Error distribution

### 5. Prediction
- Loads trained model and embeddings
- Processes new protein-ligand pairs
- Returns predicted binding affinity

## Using the Package Programmatically

You can also use the package as a library in your Python code:

```python
from kiba_model.config import KIBAConfig
from kiba_model.pipeline import KIBAModelPipeline

# Create configuration
config = KIBAConfig(
    kiba_score_threshold=100.0,
    protein_min_length=100,
    protein_max_length=2000,
    smiles_max_length=200,
    use_log10_transform=True
)

# Set file paths
config.set_file_paths(
    kiba_file='path/to/kiba.csv',
    protein_file='path/to/protein_sequences.csv',
    compound_file='path/to/compound_smiles.csv'
)

# Create pipeline
pipeline = KIBAModelPipeline(config)

# Run full pipeline
model = pipeline.run_full_pipeline()

# Or run individual steps
interactions, proteins, compounds = pipeline.run_preprocessing_pipeline()
X, y, strata = pipeline.run_feature_engineering_pipeline(interactions)
model = pipeline.run_modeling_pipeline(X, y, strata)

# Make predictions
pipeline.setup_for_prediction()
prediction = pipeline.predict(protein_id='P31749', compound_id='10184653')
print(f"Predicted KIBA score: {prediction['kiba_score']:.4f}")
```

## Input Data Requirements

### Protein Embeddings

The package requires pre-computed protein embeddings stored in an HDF5 file with the format:
- Dataset "embeddings": Numpy array of shape (num_proteins, embedding_dim)
- Dataset "protein_ids": Array of protein IDs corresponding to each embedding

### Compound Embeddings

Similarly, compound embeddings should be stored in an HDF5 file with:
- Dataset "embeddings": Numpy array of shape (num_compounds, embedding_dim)
- Dataset "cids": Array of compound IDs corresponding to each embedding

You can use models like ESM for proteins and ChemBERTa for compounds to generate these embeddings.

## Working with Results

The pipeline generates several output files:

### Filtered Data
- `data/filtered_interactions.csv`: Filtered interaction data
- `data/filtered_proteins.csv`: Filtered protein data
- `data/filtered_compounds.csv`: Filtered compound data

### Feature Matrices
- `data/X_features.npy`: Feature matrix
- `data/y_target.npy`: Target values
- `data/strata_array.npy`: Stratification labels

### Models
- `models/initial_model_[ln/log10].json`: Initial XGBoost model
- `models/final_model_[ln/log10].json`: Final XGBoost model
- `models/best_params_[ln/log10].pkl`: Best hyperparameters

### Results
- `results/metrics_[ln/log10].pkl`: Evaluation metrics
- `results/actual_vs_predicted_[ln/log10].png`: Plot of actual vs. predicted values
- `results/feature_importance.png`: Feature importance plot
- `results/prediction_distributions.png`: Distribution of predictions
- `results/error_heatmap.png`: Error heatmap
- `results/error_distribution.png`: Error distribution
- `results/residual_plot.png`: Residual plot

## Common Issues and Solutions

### ID Mismatch
If you encounter "0 valid interactions after filtering", check that your protein and compound IDs match between files. The most common causes are:
- Different ID formats (string vs. integer)
- Missing embeddings for some IDs
- Case sensitivity in IDs

Solution: Use debug mode to see sample IDs and ensure consistent formatting.

### GPU Issues
If you see warnings about GPU configuration, try:
```bash
python -m kiba_model.main --kiba-file kiba.csv --protein-file protein_sequences.csv --compound-file cid_smiles_extracted.csv --no-gpu
```

### Memory Issues
For large datasets, you might run into memory problems. Try:
- Processing in smaller batches
- Reducing the embedding dimensions
- Using a subset of your data for initial testing

## Advanced Usage

### Custom Embeddings

You can use custom embeddings by placing them in the appropriate files:
- Protein embeddings: `data/esm_embeddings.h5`
- Compound embeddings: `data/chemberta_embeddings.h5`

### Custom Transforms

To implement a custom transformation for KIBA scores:
1. Modify the `_convert_to_original_scale` method in `FeatureEngineering`
2. Update your configuration with `use_log10_transform=False` 
3. Implement your custom transformation logic

### Adding New Features

To add new features:
1. Extend the `create_feature_matrix` method in `FeatureEngineering`
2. Add your new features to the existing matrix
3. Update the dimensions as needed

## Understanding Model Output

The model predicts binding affinity in log-transformed KIBA scores. To convert back to the original scale:

- For log10 transformation: `original_kiba = (10 ** predicted_log_value) - 1`
- For natural log transformation: `original_kiba = exp(predicted_log_value) - 1e-6`

Lower KIBA scores indicate stronger binding affinity.

## Troubleshooting

### Logging

Check the logs in the `logs` directory for detailed information about each run.

For more verbose output, use:
```bash
python -m kiba_model.main --kiba-file kiba.csv --protein-file protein_sequences.csv --compound-file cid_smiles_extracted.csv --verbose
```

### Common Errors

- **Missing embedding files**: Make sure you have generated protein and compound embeddings
- **Invalid file formats**: Check that your input files match the expected formats
- **No valid interactions**: Ensure that your filtering parameters aren't too strict
- **CUDA errors**: Use `--no-gpu` if experiencing GPU-related issues

